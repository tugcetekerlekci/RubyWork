

class Character
    attr_reader :speed, :strength, :skill,:name
    
    def initialize(speed,strength,skill)
        @speed=speed
        @strength=strength
        @skill=skill
  
        @name="character"
        
            

    end
    #puts "character classini tanimladin tebrix"
    
 

def increasePoint()
    @point=point+1
    
end


end

