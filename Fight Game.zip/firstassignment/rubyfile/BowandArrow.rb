require_relative 'Weapon'


class BowandArrow  < Weapon
	def initialize()
        super(50)
	end	

end