
require_relative 'Character'



class Knight<Character
	def initialize
        super(100,50,65)
	@name= String.new("knight")
    	end
end
