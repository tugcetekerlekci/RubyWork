class Weapon
	attr_reader :power
    
    def initialize(power)
	@power=power
	end
	

end