
require_relative 'Character'


class Queen<Character
	def initialize()
        super(45,75,70)
	@name= String.new("queen")
	@strength=750
	@speed=50
	@skill=60
    @point = 1
	@luck=2 + rand(6) + rand(6)
     @point = 0
	end
end