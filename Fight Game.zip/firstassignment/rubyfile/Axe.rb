require_relative 'Weapon'




class Axe<Weapon
	def initialize()
        #@power=80
	super(80)
    end
end