require_relative 'Weapon'

class Sword<Weapon
	def initialize()
	super(70)
	end
end