
require_relative 'Weapon'

class Knife<Weapon
	def initialize()
	super(60)
    
	end
end