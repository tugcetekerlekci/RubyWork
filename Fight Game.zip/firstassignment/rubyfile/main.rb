require_relative'Character'
require_relative'Functions'
require_relative'Weapon'






$i=0
lost=[]

puts "Start!Choose your character!"
puts "Press kin for king, que for queen, kni for knight,tro for troll  "
choosen=gets().chomp()

characterss=Hash.new
characterss[1]=chooseCharacter(controlCharacter(choosen,1))



puts "you choosed your character!"

puts "character section is completed!lets choose weapon! "
puts "Press B is for BowandArrow, K is for Knife, S is for Sword, A is for Axe "

choosenWeapon=gets().chomp()


weapons=Hash.new
weapons[1]=chooseWeapon(controlWeapon(choosenWeapon),50)








puts "You choose your character and your weapon"
puts "Its time to choose your rival’s character "
 puts ("Here is the opponents defeated: \n")
puts lost
puts(" You have " + (3-$i).to_s + " more rival to defeat ")
puts "Press kin for king, que for queen, kni for knight,tro for troll  "

#puts "By the way,you should not choose #{characterss[1].name}"

rivalCharacter=gets().chomp()

#nameOfEnemy=controlCharacter(rivalCharacter,1)
characterss[2]=chooseCharacter(controlCharacter(rivalCharacter,1))
characterss[2]=controlEnemy(characterss[1],characterss[2])




randomWeaponDeterminer=0 + rand(4)
rivalWeapon=chooseWeapon('X',randomWeaponDeterminer)
weapons[2]=rivalWeapon
############
f1=fightClub(characterss[1],characterss[2],weapons[1],weapons[2],lost)
if f1=='1'
    puts "Press B is for BowandArrow, K is for Knife, S is for Sword, A is for Axe "
    choosenWeapon=gets().chomp()
    controlWeapon(choosenWeapon)
    weapons=Hash.new
    weapons[1]=chooseWeapon(choosenWeapon,50)





    puts "You choose your character and your weapon"
    puts "Its time to choose your rival’s character "
    puts(" You have " + (3-$i).to_s + " more rival to defeat ")
    puts "Press kin for king, que for queen, kni for knight,tro for troll  "
    puts "By the way,you should not choose #{characterss[1].name} because its you"

    rivalCharacter=gets().chomp()
    characterss[2]=chooseCharacter(controlCharacter(rivalCharacter,1))
    characterss[2]=controlEnemy(characterss[1],characterss[2])


    randomWeaponDeterminer=0 + rand(4)
    rivalWeapon=chooseWeapon('X',randomWeaponDeterminer)
    weapons[2]=rivalWeapon
    f2=fightClub(characterss[1],characterss[2],weapons[1],weapons[2],lost)
    if f2=='1'
        
        
        puts "Press B is for BowandArrow, K is for Knife, S is for Sword, A is for Axe "
        choosenWeapon=gets().chomp()
        controlWeapon(choosenWeapon)
        weapons=Hash.new
        weapons[1]=chooseWeapon(choosenWeapon,50)
        
        
        
        
        
        
        puts "You choose your character and your weapon"
        puts "Its time to choose your rival’s character "
        puts ("Here is the opponents defeated: \n")
        puts lost
        puts(" You have " + (3-$i).to_s + " more rival to defeat ")
        puts "Press kin for king, que for queen, kni for knight,tro for troll  "
        puts "By the way,you should not choose #{characterss[1].name} because its you"
        
        rivalCharacter=gets().chomp()
        characterss[2]=chooseCharacter(controlCharacter(rivalCharacter,1))
        characterss[2]=controlEnemy(characterss[1],characterss[2])

        
        randomWeaponDeterminer=0 + rand(4)
        rivalWeapon=chooseWeapon('X',randomWeaponDeterminer)
        weapons[2]=rivalWeapon
        fightClub(characterss[1],characterss[2],weapons[1],weapons[2],lost)
      
    end
end








