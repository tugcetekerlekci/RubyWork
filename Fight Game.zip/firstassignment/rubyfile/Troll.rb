require_relative 'Character'

class Troll<Character
	def initialize()
	super(40,50,100)
	@name= String.new("troll")

	end
end