require_relative 'King'
require_relative 'Queen'
require_relative 'Character'
require_relative 'Knight'
require_relative 'Weapon'
require_relative'BowandArrow'
require_relative'Sword'
require_relative 'Knife'
require_relative'Axe'
require_relative'Troll'



def chooseCharacter(choosen)
    
        if choosen=="kin"
            character1=King.new
            return character1
        elsif choosen=="que"
            character1=Queen.new
            return character1
        elsif choosen=="kni"
            character1=Knight.new
            kniflag=true
            return character1
        elsif choosen=="tro"
            character1=Troll.new
      
            return character1
        end

end

def chooseWeapon(choosenName,luckyNum)
	if(choosenName=='A' || luckyNum==0)
	weapon1=Axe.new
    
	end
	
	if(choosenName=='K' || luckyNum==1)
	weapon1=Knife.new
    #   puts weapon1.inspect
	end
	
	if(choosenName=='S' || luckyNum==2)
	weapon1=Sword.new
    #puts weapon1.inspect
	end
	
	if(choosenName=='B' || luckyNum==3)
	weapon1=BowandArrow.new
    #puts weapon1.inspect
	end
   
    return weapon1
end

def controlCharacter(choosen,control1)
    
        while (control1==1)
            if choosen=="kin" || choosen=="kni" || choosen=="que" || choosen=="tro"
            control1=nil
            return choosen
            break
            
            else
            puts "The character is not defined please select among king queen and knight"
            puts "Press kin for king, que for queen, kni for knight  "
            choosen=gets().chomp()
            end
        
        end
    
end


def controlWeapon(choosenWeaponLetter)
    control2=1
    while (control2==1)
        if choosenWeaponLetter=='B' || choosenWeaponLetter=='K' || choosenWeaponLetter=='A' || choosenWeaponLetter=='S'
            control2=nil
            
            break
            
            else
            puts "the weapon that you selected is not defined"
            puts "Press B is for BowandArrow, K is for Knife, S is for Sword, A is for Axe "
            choosenWeaponLetter=gets().chomp()
        end
        
    end
    return choosenWeaponLetter
end


def fightClub(competitor1,competitor2,gun1,gun2,lost)
luck=50 + rand(50)

        
    firstResult=competitor1.skill+competitor1.speed+competitor1.strength+gun1.power+luck
    secondResult=competitor2.skill+competitor2.speed+competitor2.strength+gun2.power
    
    if firstResult<secondResult
        puts "You lost the game please try again"
        return '2'
    elsif firstResult>secondResult
        puts "You win the round"
        puts "Next round is beginning"
        lost[$i]=competitor2.name
        $i=$i+1
        return '1'
    end
    
end




def controlEnemy(rival,choosenCharacter)
    flag=1
    while flag==1
        if rival.name==choosenCharacter.name
              puts "You're #{choosenCharacter.name}"
              puts "The rival character can't be same with your character! please choose another character, try again"
              puts "Press kin for king, que for queen, kni for knight "
              newRivalName=gets().chomp()
              rival=chooseCharacter(controlCharacter(newRivalName,1))
             
              
              
        else
            flag==nil
                break
        end
        
    end
    
       return rival
    


end



