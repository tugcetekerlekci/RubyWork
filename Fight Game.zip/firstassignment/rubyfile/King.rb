
require_relative 'Character'


class King<Character
	def initialize()
    super(40,100,50)


	@name= String.new("king")

	end
end