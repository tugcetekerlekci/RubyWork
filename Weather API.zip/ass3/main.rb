require 'open-uri'
require 'json'
require "rubygems"
require "net/http"
require "json"
require_relative 'Location'
require_relative 'PublicIP'
require_relative 'Weather'


w1=Weather.new(Location.new(PublicIP.new))
w1.open



