require_relative 'InterfaceAPI'



class Weather<InterfaceAPI
    
    def initialize(locationObject)
        @locationResult
        @locationObject = locationObject
    
    end


    def open
        
        begin
        @locationResult = @locationObject.open
        weather=Net::HTTP.get(URI("http://api.openweathermap.org/data/2.5/weather?q="+@locationResult["city"]+"&units=metric&APPID=9ad38e257d51b86728a148032a93d750"))
        
        weatherResult=JSON.parse(weather)
        puts "Today's weather at Binghamton:"
        puts weatherResult["main"]["temp"]
        
        rescue
        puts ("there is an error.")
        
        end
        end
end