class InterfaceAPI
    def initiailize
        raise "Abstract"
    end
    
    def open
        raise "Abstract"
    end

end