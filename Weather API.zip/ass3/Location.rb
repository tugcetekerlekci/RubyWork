require 'open-uri'
require 'json'
require_relative 'InterfaceAPI'




class Location<InterfaceAPI
    def initialize(ipObject)
        @ipObject = ipObject
        @ipAddress
        @locationResult=" "
    
    end

    def open
        begin
        @ipAddress = @ipObject.open
        location=Net::HTTP.get(URI("http://ip-api.com/json/"+ @ipAddress))
        
        @locationResult=JSON.parse(location)
        
        return @locationResult
        rescue
        # puts "there is an error"
        end
    end





end