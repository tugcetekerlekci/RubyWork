require 'open-uri'
require 'json'
require_relative 'InterfaceAPI'


class PublicIP<InterfaceAPI

    def initialize
        @ipResultPass= "empty" 
        
      
    end
    
    def open
    begin
    ip = Net::HTTP.get(URI("http://api.ipify.org?format=json"))

    uri = URI('http://api.ipify.org?format=json')
    
    
    ipResult=JSON.parse(ip)
    @ipResultPass=ipResult["ip"]
    return @ipResultPass
    
    rescue
    #puts ("there is an error.")
    
    end
    
    end
    


end