

require_relative 'Chat'

class ChatBot<Chat

    
    def greeting()
        puts "Hello"
    end
    
    
    def goodbye()
        puts "It was good to talk to you.I wanna say good bye."
    end
    

    def update(userc,input)
      
      
      if(@matchResponse.control(input)==1)
      elsif(@questionResponse.control(input)==1)
      elsif(@goodbyeResponse.control(input)==1)
            @user.check=0
      elsif(@noMatchResponse.control(input)==1)
      
            
      end
    
    end
    
    
    
    def strategy(input,strategy)
        
        strategy.control(input)

    end


end
