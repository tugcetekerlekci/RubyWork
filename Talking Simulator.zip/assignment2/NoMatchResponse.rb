require_relative'Response'

class NoMatchResponse<Response

attr_accessor:statement
attr_reader:statement
attr_writer:statement

attr_accessor:seperateResponses
attr_reader:seperateResponses
attr_writer:seperateResponses



def initialize
    @statement=Array.new
    @responses=Array.new
    @seperateResponses=Array.new
    @data=Hash.new
    
    
    f = File.open("/Users/tugcetekerlekci/Desktop/assignment2/chatter.txt", "r")
    File.write(f, File.read(f).gsub(/\n+/,"\n"))
    counter=0;
    
    f.each_line do |line|
        
        
        line=line.chomp
        @statement[counter]=line.partition(':').first
        @responses[counter]=line.partition(':').last
        counter=counter+1
        
    end
    
    
    for i in 0..11
        
        @seperateResponses[i]=@responses[i].split(";")
        
    end
    
    
    for i in 0..11
        @data[i]={@statement[i]=>@seperateResponses[i]}
        
        
    end
    
    
    
end

def control(input)
     bool=0
    for i in 0..11
        if ((input.include? @statement[i])==false)
            bool=1
        end
        
    end
            if(bool==1)
            length=seperateResponses[i].length
            index=rand(0 .. length-1)
            answer =  @seperateResponses[9][index]
        end
            puts(answer)
    return bool
    
end
        
        

        
        
        

end