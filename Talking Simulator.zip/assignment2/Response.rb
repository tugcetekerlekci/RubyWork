class Response
    
    
    def control(input)
    end



end