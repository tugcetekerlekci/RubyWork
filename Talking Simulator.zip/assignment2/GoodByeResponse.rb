class GoodByeResponse<Response

    def control(input)
        splits = input.split(" ")
        size = splits.length
        if(size==1)
        puts "goodbye"
        return 1;
        end
    
    end

end