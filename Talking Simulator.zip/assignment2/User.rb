require "observer"

class User
    
    attr_accessor :lines
    attr_reader :lines
    attr_writer :lines
    
    
    attr_accessor :check
    attr_reader :check
    attr_writer :check
    include Observable
    
    def initialize
        @lines=Array.new
        @check=1
    end
    
    
    def readFile
        
       
        counter=0
        
        f = File.open("/Users/tugcetekerlekci/Desktop/assignment2/script.txt", "r")
        
        
        f.each_line do |line|
            
            @lines[counter]=line
            #puts(@lines[counter])
            
            counter=counter+1
        end
        

    

    end
    

    def dialogue()
    
     if(File.exist?('script.txt'))
         
         
         readFile
         
         for i in 0..10
             puts(@lines[i])
             changed
             notify_observers(self,@lines[i])
             
         end

     
     else
            while(true)
                if(@check==1)
                input=gets
                input=input.chomp
                changed
                notify_observers(self,input)
                else
                    break
                end
            end
     end
    
    #line="hello"
    #changed
    #notify_observers(line)
    
    
    end
   





end