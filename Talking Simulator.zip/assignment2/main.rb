require_relative 'ChatBot'
require_relative 'Chat'
require_relative 'User'

require_relative 'MatchResponse'
require_relative 'NoMatchResponse'
require_relative 'QuestionResponse'
require_relative 'GoodByeResponse'



u1=User.new()
c1=ChatBot.new(u1)
c1.chat()







#a="are"
#m1=MatchResponse.new()
#m1.control(a)

