class QuestionResponse<Response

    
    def control(input)
        
        lastChar=input[-1, 1]
        
        if(lastChar=='?')
            puts "Interesting, tell me what you think first."
            return 1
        end
        
        return 0
        
    end


end