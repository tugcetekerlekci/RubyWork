class Chat

    

    def initialize(user)
        
        @user=user
        user.add_observer(self)
        
        @matchResponse=MatchResponse.new
        @noMatchResponse=NoMatchResponse.new
        @questionResponse=QuestionResponse.new
        @goodbyeResponse=GoodByeResponse.new
        

    
    end
    
    def chat()
        greeting()
        @user.dialogue
        goodbye()

    end
    
  





end