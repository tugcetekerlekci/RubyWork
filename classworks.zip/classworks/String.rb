class String
    
    def initialize(string1,string2)
        @string1=string1
        @string2=string2
    
    end
    
    def Swap()
        puts(@string1[2])
        puts(@string2[4])
    
        temp1=@string1[2]
        temp2=@string2[4]
        @string1[2]=temp2
        @string2[4]=temp1
    
        puts(@string1)
        puts(@string2)
    end
    

end

begin
    
    puts("Enter first string")
    
    string1=gets.chomp()
    
  
 
    if string1.length<3
        puts("WRONG! SHOULD BE MORE THAN 3 LETTERS")
    
    end
    

    puts("Enter second string")
    string2=gets.chomp()

    if string2.length<5
        puts ("WRONG! SHOULD BE MORE THAN 5 LETTERS")
    
    end


    obj1=String.new(string1,string2)
    obj1.Swap()


rescue
    puts "Something Wrong Happened"
end


