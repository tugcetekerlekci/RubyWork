#Batuhan Ertas
#Elif Tugce Tekerlekci
#Yigit Alp Ciray

class HomeTheater
	
	def initialize(isScary, audience, input)
		@isScary = isScary
		@audience = audience
		@input = input
	end
	
	def dimLights(@isScary)
		if @isScary
			#...
		else
			#...
		end
	end
	def turnOn()
		#...
	end
	def changeRemote(@input)
		#...
	end
	
	def setVolume(@audience)
		#...
	end
	def play()
		#...
	end
	
	def playTheMovie(@isScary, @input, @audience)
		dimLights()
		turnOn()
		changeRemote(@input)
		setVolume(@audience)
		play()
	end
end

class HomeTheaterAdapter
	def initialize(isScary, audience, input)
		@subject = HomeTheater.new(isScary, audience, input)
	end 	
	def playMovie()
		@subject.playTheMovie(@subject.isScary, @subject.audience, @subject.input)
	end
end

movie = HomeTheaterAdapter.new(true, 150, input)
movie.playMovie()


