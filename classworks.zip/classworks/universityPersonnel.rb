#Batuhan Ertas
#Elif Tugce Tekerlekci
#Yigit Alp Ciray

def GenerateReport
	def initialize(personnel)
		personnel.makeReport()
	end
end

#first solution
def AFacultyAdapter
	def initialize (af)
	
	def makeReport
		af.makeAdminReport()
	end
end

af = AFacultyAdapter(AdminFaculty.new)
r = GenerateReport.new(af)

##end of first solution

#second solution
#like overriding the AdminFacuty Class

require 'AdminFaculty'
class AdminFaculty
	def makeFaculty
		makeAdminReport
	end
end

##end of second solution

#third solution

af = AdminFaculty.new

class << af
	def makeReport 
	
	end
end

af.makeReport
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
