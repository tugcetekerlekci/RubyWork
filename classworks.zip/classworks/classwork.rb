#Batuhan Ertas
#Yigit Alp Ciray
newObj = StartWithDesign.new
printStuff("cs342.txt", newObj)

newObj2 = LongerThanSeven.new
printStuff("cs342.txt", newObj2)

#####################

class Sort 
	def sort()
		raise ("Abstract")
	end
end

class BubbleSort < Sort
	def sort()
		puts "bubblesort"
	end
end

class MergeSort < Sort
	def sort()
		puts "mergesort"
	end
end

class QuickSort < Sort
	def sort()
		puts "quicksort"
	end
end

def sortDataset(dataset, sort)
	sort.sort(dataset)
end