#Batuhan Ertas
#Yigit Alp Ciray
#Elif Tugce Tekerlekci
def isDesign(str)
	if str[0...6] == "design"
		puts "#{str} starts with design"
	end
end

def isGreaterSeven(str)
	if str.length > 7
		puts "#{str} 's length is greater than 7 characters"
	end
end
def isPalindrome(stringArray)
	puts "will compare every string in the array"
end
def check(string, stringArray)
	isDesign(line)
	isGreaterSeven(line)
	stringArray.push(line)
end
strings = Array.new
fileobj = File.new("textFile.txt", "r")
while (line = fileobj.gets.chomp)
	check(line, strings)
end
fileobj.close() 

isPalindrome(strings)
