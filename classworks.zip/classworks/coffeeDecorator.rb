#Batuhuan Ertas
#Elif Tugce Tekerlekci
#Yigit Alp Ciray
class CondimentsInterface
	def initialize()
		raise "abstract"
	end
	def cost()
		raise "abstract"
	end
end

class Milk < CondimentsInterface 
	def initialize(coffee)
		@price = #some price
		@coffee = coffee
	end
	def cost()
		puts @coffee.cost
	end
end

class HouseBlend < CondimentsInterface
	def initialize(condiment)
		@condiment = condiment
	end
	def cost()
		@condiment.cost
	end
end

drink = Milk.new(Soy.new(Houseblend.new))
drink.cost
