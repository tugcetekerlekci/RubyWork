#Batuhan Ertas
#Yigit Alp Ciray
#Elif Tugce Tekerlekci
class Iterator
	@index
	@size
	def initialize()
		raise "abstract"
	end
	def getIterator()
		raise "abstract"
	end
	def getNext()
		raise "abstract"
	end
end

class Customer
	def initialize(time)
		@time = time
		@
	end
	def wakeUp()
	
	end
end

def wakeUpCustomers(customerArray)
	while customerArray.asNext
		customerArray.getIterator().wakeUp()
		customer.getNext()
	end
end
		
		