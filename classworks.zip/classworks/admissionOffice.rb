#Batuhan Ertas
#Elif Tugce Tekerlekci
#Yigit Alp Ciray
class Documentation
	def toHTML(fileName)
		raise "Abstract"
	end
end

class Jpeg < Documentation
	def toHTML(fileName)
		puts "Converted to JPEG"
	end
end

class Pdf < Documentation
	def toHTML(fileName)
		puts "Converted to PDF"
	end
end

class Docx < Documentation
	def toHTML(fileName)
		puts "Converted to Docx"
	end
end

format = Jpeg.new

def fileToHTML(fileName, format)
	format.toHTML(fileName)
end

