class Information
	def sendInfo(uniInfo)
		raise "Abstract Class"
	end
end

class SMS < Information
	def sendInfo(uniInfo)
		#some code
	end
end

class Email < Information
	def sendInfo(uniInfo)
		#some code
	end
end
class WebsiteUpdate < Information
	def sendInfo(uniInfo)
		#some code
	end
end
class RSSFeed < Information
	def sendInfo(uniInfo)
		#some code
	end
end

def info(format, uniInfo)
	format.sendInfo(uniInfo)
end
