# Batuhan Ertas
# Yigit Alp Ciray
# Elif Tugce Tekerlekci

class Type1 < Student #grad, undergrad, freshman, junior
	def func
		raise "abstract"
	end
end

class Type2 < Student #foreign, domestic
	def func
		raise "abstract"
	end
end

class Type 3 < Student #funded, full-time, part-time
	def func
		raise "abstract"
	end
end

class Grad < Type1
	def func
		#some code
	end
end
#same for undergrad, ...

class Foreign < Type2
	def func
		#some code
	end
end
#same for domestic

class Funded < Type3
	def func
		raise "abstract"
	end
end
# same for full-time, part-time

class Student
	def initialize(type1, type2, type3)
		@type1 = type1
		@type2 = type2
		@type3 = type3
	end
	def func
		@type1.func
	end
	def func2
		@type2.func
	end
	def func3
		@type3.func
	end
end