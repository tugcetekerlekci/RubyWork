#Yigit Alp Ciray
#Elif Tugce Tekerlekci
#Batuhan Ertas
class HTML
	def organize()
		raise "abstract method"
	end
end

class Head < HTML
	def organize()
		@children.each { |ch|
			ch.oragnize()
		}
	end
end

class Body < HTML
	def organize()
		@children.each { |ch|
			ch.organize()
		}
	end	
end

class Section < HTML
	def organize()
		#organize the sections
	end 
end

class Button < HTML
	def organize()
		#organize the sections
	end 
end

class Forms < HTML
	def organize()
		#organize the sections
	end 
end

class Images < HTML
	def organize()
		#organize the sections
	end 
end