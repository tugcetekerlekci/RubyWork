def printTheWord(abc)
    
yield(abc)

end


printTheWord('hello')
{
|word| puts word

}