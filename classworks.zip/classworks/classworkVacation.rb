#Batuhan Ertas
#Elif Tugce Tekerlekci
#Yigit Alp Ciray
class Trip
	def arrive(transportation)
		raise "Abstract"
	end
	def visit(visitOfDay)
		raise "Abstract"
	end
	def returnBack()
		raise "Abstract"
	end
	def makeTrip(p1, p2, p3, p4, p5, p6, p7)
		arrive()
		visit()
		visit()
		visit()
		visit()
		visit()
		returnBack()
		hook()
	end
	def hook()
		
	end
end

class Package1 < Trip
	
end

########################### su an bunu extend edebilirsin ama TEMPLATE METHOD'un en buyuk sorunlarindan bunu ilerde diyelim ki
						#	bunu 3 gune indirmek istedin o zaman yapamiyorsun
class VacationPlanner
	def planVacation
		arrive()
		visitDay1()
		visitDay2()
		visitDay3()
		visitDay4()
		visitDay5()
		if(extend())
			extendStay()
		end
		returnHome()
	end
end

