#Batuhan Ertas
#Yigit Alp Ciray
#Elif Tugce Tekerlekci
def measurementChanged()
	temp = self.getTemprature()
	humidty = self.getHumidity()
	pressure = self.getPressure()
	@currentConditionsDisplay.update(temp, humidity, pressure)
	@statiscticsDisplay.update(temp, humidity, pressure)
	@forecastDisplay.update(temp, humidity, pressure)
end