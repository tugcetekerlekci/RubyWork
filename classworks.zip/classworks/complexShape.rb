#Yigit Alp Ciray
#Batuhan Ertas
#Elif Tugce Tekerlekci
class Shape
	def renderShapeToScreen()
		raise "Abstract"
	end
	def explodeShape(Location)
		raise "Abstract"
	end
	def delete()
		raise "Abstract"
	end
end

class Rectangle < Shape
	def renderShapeToScreen()
		#some code
	end
	def explodeShape(Location)
		#some code
	end
	def delete()
		#some code
	end
end

class Line < Shape
	def renderShapeToScreen()
		#some code
	end
	def explodeShape(Location)
		#some code
	end
	def delete()
		#some code
	end
end

dec ComplexShape < Shape
	def renderShapetoScreen()
		childeren.each {|c|
			c.renderShapetoScreen()
		}
	end
	def explodeShape(Location)
		childeren.each {|c|
			c.renderShapetoScreen()
		}
	end
	def delete()
		childeren.each {|c|
			c.renderShapetoScreen()
		}
	end
end