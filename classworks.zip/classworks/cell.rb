class SpreadSheet

	def initialize(observable)
		@cell = observable
	end
	def formula(cell)
		#some formula here....
	end
	
	def updateCells()
		cells.each do { |o|
			o.formula(self)
		}
end


##########################################
class Cell #both subject and observer so it should be a combination of both observer and subject
	def initialize
		o=[]
	end
	
	def notify()
		observer.each do { |o|
			o.update(self)			
		}	
	end
	def update()
	
	def register() #registerda array'e atiyoruz 
	
	def deregister() #deregisterda array'den aliyoruz


end