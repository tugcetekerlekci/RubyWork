#Batuhan Ertas
#Yigit Alp Ciray
#Elif Tugce Tekerlekci
class Software
	def initialize(extraP, documents, replace)
		raise "abstract"
	end
	
	def install()
		if extraP
			@extraPackage.call()
		end
		if documents
			@documantation.call()
		end
		if replace
			@replaceOldFiles.call
		else
			@backUpOldFiles.call
		end
	end
	def installExtraPackage(extraPackage)
		@extraPackage = extraPackage
	end
	def installDocumentation(documantation)
		@documantation = documantation
	end
	def replaceTheOldFiles(replaceOldFiles)
		@replaceOldFiles = replaceOldFiles
	end
	def backUpOldFiles(backUpOldFiles)
		@backUpOldFiles = backUpOldFiles
	end
end

extraPackage = Proc.new {
	#some code
}


documantation = Proc.new {
	#some code
}


replaceTheOldFiles = Proc.new {
	#some code
}


backUpOldFiles = Proc.new {
	#some code
}