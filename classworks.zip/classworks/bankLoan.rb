class Client
	attr_reader:name, :birthdate
	def initialize(name, birthdate)
		@name = name
		@birthdate = birthdate
	end
end

class Customer < Client
	def initialize(name, birthdate, customerID)
		super(name, birthdate)
		@customerID = customerID
	end
	def check(year, loan)
		loan.check(@customerID, year)
		puts loan.stocks 	
	end
	end
end

class BankEmployee < Client
	def initialize(name, birthdate, employeeID)
		super(name, birthdate)
		@employeeID = employeeID
	end
	def check(year, loan)
		loan.check(@customerID, year)	
	end
end

class Loan
	attr_reader:stocks
	def initialize(customerID, balance, score, stocks, potential)
		@customerID = customerID
		@balance = balance
		@score = score
		@stocks = stocks
		@potential = potential
	end

	def check(customerID, year)
		checkAssets(customerID)
		checkCreditScore(customerID)
		checkPotential(customerID, year)
	end
end
