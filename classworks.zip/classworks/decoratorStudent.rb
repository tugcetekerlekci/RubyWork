class StudentDecorator
    def initialize(student)
        @student=student
    end
    
    def display
    end

end

class Freshman<StudentDecorator
    def initialize(student)
        super(student)
    end
    
    
    def display()
        student.description = “Freshman”
        student.display()
    end
        


end

class SimpleStudent
    def display
        


    end


end